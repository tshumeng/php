# Udger Test data
This repository contains test data for udger local parser. 

The test data includes a limited set of data.
Full data available only to users with Local parser subscription (https://udger.com/prices).

### Author
The Udger.com Team (info@udger.com)
